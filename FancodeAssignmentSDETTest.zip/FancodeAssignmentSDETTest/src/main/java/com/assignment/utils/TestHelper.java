package com.assignment.utils;

import com.assignment.constants.Constants;

public class TestHelper {


    public static boolean LatituteLongitudeCheckerForUser(double latitude, double longitude) {
        if (latitude >= Constants.LAT_START && latitude <= Constants.LAT_END && longitude >= Constants.LNG_START
                && longitude <= Constants.LNG_END) {
            return true;
        }
        return false;
    }

    public static double CalculateTaskCompletedPercentage(double completedTask, double totalTask) {
        return (completedTask / totalTask) * 100;
    }
}
