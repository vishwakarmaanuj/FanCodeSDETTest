package com.assignment.constants;

public class Constants {
	public static final double LAT_START = -40;
    public static final double LAT_END = 5;
    public static final double LNG_START = 5;
    public static final double LNG_END = 100;
}
