package com.assignment.constants;

public class BaseUrl {
    public static final String BASE_URI = "http://jsonplaceholder.typicode.com";

}
